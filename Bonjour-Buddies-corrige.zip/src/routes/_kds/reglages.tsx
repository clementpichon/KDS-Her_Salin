import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Save,
  RotateCcw,
  Plus,
  Trash2,
  Pencil,
  Check,
  X,
  Package,
  Sliders,
  Carrot,
  Pizza as PizzaIcon,
  Store,
  Monitor,
  Bell,
  ShieldAlert,
  Sandwich,
  Zap,
} from "lucide-react";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { useSettings, useOrders, useIngredients, usePaninoOrderItems } from "@/hooks/use-kds-data";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { computeStock } from "@/lib/scheduling";
import type { Settings, Pizza, Ingredient, PaninoProduct } from "@/lib/kds-types";


type SettingsForm = Omit<Settings, "id" | "paton_losses">;

type LocalControlSettings = {
  serviceOpen: boolean;
  testMode: boolean;
  compactKitchen: boolean;
  highContrast: boolean;
  soundNewOrder: boolean;
  soundLateOrder: boolean;
  lockStations: boolean;
  stockWarningThreshold: number;
  lateWarningMinutes: number;
  disabledPaninoKeys: string[];
};

const LOCAL_CONTROL_KEY = "hersalin_control_settings_v1";
const DEFAULT_LOCAL_CONTROL: LocalControlSettings = {
  serviceOpen: true,
  testMode: false,
  compactKitchen: true,
  highContrast: false,
  soundNewOrder: true,
  soundLateOrder: true,
  lockStations: false,
  stockWarningThreshold: 20,
  lateWarningMinutes: 5,
  disabledPaninoKeys: [],
};

export const Route = createFileRoute("/_kds/reglages")({
  head: () => ({
    meta: [
      { title: "Réglages — Her Salin" },
      { name: "description", content: "Réglages Her Salin : stock initial de pâtons, capacité du four, temps de cuisson et reset de journée." },
      { property: "og:title", content: "Réglages du système" },
      { property: "og:description", content: "Stock pâtons, paramètres de production et reset journée." },
    ],
    links: [{ rel: "canonical", href: "/reglages" }],
  }),
  component: Reglages,
});

function Reglages() {
  const settings = useSettings();
  const { orders } = useOrders();
  const { items: paninoItems } = usePaninoOrderItems();
  const [localSettings, setLocalSettings] = useLocalControlSettings();
  const [form, setForm] = useState<Partial<SettingsForm>>({});
  const [resetCode, setResetCode] = useState("");

  useEffect(() => {
    if (settings)
      setForm({
        oven_capacity: settings.oven_capacity,
        cook_time_sec: settings.cook_time_sec,
        prep_time_per_pizza_sec: settings.prep_time_per_pizza_sec,
        boxing_time_sec: settings.boxing_time_sec,
        safety_margin_sec: settings.safety_margin_sec,
        batch_interval_sec: settings.batch_interval_sec,
        initial_paton_stock: settings.initial_paton_stock,
      });
  }, [settings]);

  if (!settings) return <div className="p-8">Chargement…</div>;

  const stock = computeStock(orders, settings, paninoItems);
  const activeOrders = orders.filter((order) => order.status !== "delivered");
  const pendingPizzaCount = activeOrders.reduce((total, order) => total + (order.items?.length ?? 0), 0);
  const pendingPaninoCount = paninoItems.filter((item) => item.status !== "done").length;

  const save = async () => {
    const { error } = await supabase.from("settings").update(form).eq("id", 1);
    if (error) return toast.error("Erreur");
    toast.success("Réglages enregistrés");
  };

  const resetDay = async () => {
    if (resetCode.trim().toUpperCase() !== "RESET") {
      toast.error("Tapez RESET pour confirmer la réinitialisation");
      return;
    }
    const { data: ordersToDelete } = await supabase.from("orders").select("id");
    const ids = (ordersToDelete ?? []).map((o) => o.id);
    if (ids.length > 0) {
      await supabase.from("order_items").delete().in("order_id", ids);
      await supabase.from("panino_order_items").delete().in("order_id", ids);
      await supabase.from("orders").delete().in("id", ids);
    }
    await supabase.from("settings").update({ paton_losses: 0 }).eq("id", 1);
    setResetCode("");
    toast.success("Journée réinitialisée — stock pâtons complet");
  };


  return (
    <div className="mx-auto max-w-2xl p-4 md:p-8 space-y-4">
      <h1 className="text-2xl md:text-3xl font-bold">Réglages du système</h1>
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Commandes" value={activeOrders.length} />
        <Stat label="Pizzas actives" value={pendingPizzaCount} />
        <Stat label="Pani'NO actifs" value={pendingPaninoCount} />
      </div>
      <Accordion type="single" collapsible className="space-y-3">
        <AccordionItem value="service" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><Store className="h-5 w-5 text-primary" /><span className="text-lg font-bold">Service</span></span>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-3">
              <ToggleRow
                label="Service ouvert"
                description="Indicateur de pilotage pour savoir si la prise de commande doit rester active."
                checked={localSettings.serviceOpen}
                onCheckedChange={(serviceOpen) => setLocalSettings({ ...localSettings, serviceOpen })}
              />
              <ToggleRow
                label="Mode test"
                description="Repère visuel pour travailler avec des commandes de démonstration sans les confondre avec le service réel."
                checked={localSettings.testMode}
                onCheckedChange={(testMode) => setLocalSettings({ ...localSettings, testMode })}
              />
              <ToggleRow
                label="Verrouiller les postes"
                description="Préférence locale pour garder chaque tablette sur son poste pendant le service."
                checked={localSettings.lockStations}
                onCheckedChange={(lockStations) => setLocalSettings({ ...localSettings, lockStations })}
              />
              <div className={`rounded-xl border px-4 py-3 text-sm font-semibold ${localSettings.serviceOpen ? "border-secondary/40 bg-secondary/10 text-secondary" : "border-destructive/40 bg-destructive/10 text-destructive"}`}>
                {localSettings.serviceOpen ? "Service marqué ouvert" : "Service marqué fermé"}
                {localSettings.testMode && <span className="ml-2 rounded-full bg-primary px-2 py-0.5 text-xs text-primary-foreground">TEST</span>}
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="stock" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><Package className="h-5 w-5 text-primary" /><span className="text-lg font-bold">Stock pâtons</span></span>
          </AccordionTrigger>
          <AccordionContent>
            <p className="text-sm text-muted-foreground mb-4">Saisissez le stock initial en début de service.</p>
            <div className="grid grid-cols-3 gap-4 mb-4">
              <Stat label="Initial" value={settings.initial_paton_stock} />
              <Stat label="Pertes" value={settings.paton_losses} tone="destructive" />
              <Stat label="Restant" value={stock} tone={stock < localSettings.stockWarningThreshold ? "destructive" : "secondary"} />
            </div>
            <div className="grid gap-3 sm:grid-cols-[1fr_auto_auto]">
              <div className="flex-1">
                <Label htmlFor="init">Stock initial</Label>
                <Input id="init" type="number" value={form.initial_paton_stock ?? 0} onChange={(e) => setForm({ ...form, initial_paton_stock: Number(e.target.value) })} className="h-11" />
              </div>
              <Button onClick={save} className="self-end h-11 font-bold"><Save className="mr-1 h-4 w-4" /> Enregistrer</Button>
            </div>
            <div className="mt-4 rounded-xl border bg-background p-3">
              <Field
                id="stock_warning"
                label="Alerte stock faible (pâtons restants)"
                value={localSettings.stockWarningThreshold}
                onChange={(stockWarningThreshold) => setLocalSettings({ ...localSettings, stockWarningThreshold })}
              />
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="prod" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><Sliders className="h-5 w-5 text-primary" /><span className="text-lg font-bold">Paramètres production</span></span>
          </AccordionTrigger>
          <AccordionContent className="space-y-4">
            <div className="grid gap-2 sm:grid-cols-3">
              <Button variant="outline" onClick={() => setForm({ ...form, cook_time_sec: 75, prep_time_per_pizza_sec: 100, boxing_time_sec: 120, safety_margin_sec: 90 })}>
                <Zap className="mr-1 h-4 w-4" /> Service rapide
              </Button>
              <Button variant="outline" onClick={() => setForm({ ...form, cook_time_sec: 90, prep_time_per_pizza_sec: 120, boxing_time_sec: 180, safety_margin_sec: 120 })}>
                Standard
              </Button>
              <Button variant="outline" onClick={() => setForm({ ...form, cook_time_sec: 110, prep_time_per_pizza_sec: 160, boxing_time_sec: 210, safety_margin_sec: 180 })}>
                Service chargé
              </Button>
            </div>
            <Field id="oven_capacity" label="Capacité four (pizzas simultanées)" value={form.oven_capacity} onChange={(v) => setForm({ ...form, oven_capacity: v })} />
            <Field id="cook_time_sec" label="Temps de cuisson (secondes)" value={form.cook_time_sec} onChange={(v) => setForm({ ...form, cook_time_sec: v })} />
            <Field id="prep_time_per_pizza_sec" label="Préparation par pizza (secondes)" value={form.prep_time_per_pizza_sec} onChange={(v) => setForm({ ...form, prep_time_per_pizza_sec: v })} />
            <Field id="boxing_time_sec" label="Mise en boîte (secondes)" value={form.boxing_time_sec} onChange={(v) => setForm({ ...form, boxing_time_sec: v })} />
            <Field id="batch_interval_sec" label="Intervalle entre enfournements (secondes)" value={form.batch_interval_sec} onChange={(v) => setForm({ ...form, batch_interval_sec: v })} />
            <Field id="safety_margin_sec" label="Marge de sécurité (secondes)" value={form.safety_margin_sec} onChange={(v) => setForm({ ...form, safety_margin_sec: v })} />
            <Field
              id="late_warning"
              label="Alerte retard cuisine (minutes)"
              value={localSettings.lateWarningMinutes}
              onChange={(lateWarningMinutes) => setLocalSettings({ ...localSettings, lateWarningMinutes })}
            />
            <Button onClick={save} className="w-full h-12 text-base font-bold"><Save className="mr-2 h-4 w-4" /> Enregistrer</Button>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="display" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><Monitor className="h-5 w-5 text-primary" /><span className="text-lg font-bold">Affichage cuisine</span></span>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-3">
              <ToggleRow
                label="Cartes compactes"
                description="Préférence pour afficher plus de commandes à l'écran."
                checked={localSettings.compactKitchen}
                onCheckedChange={(compactKitchen) => setLocalSettings({ ...localSettings, compactKitchen })}
              />
              <ToggleRow
                label="Contraste renforcé"
                description="Mode recommandé pour les tablettes en cuisine ou forte luminosité."
                checked={localSettings.highContrast}
                onCheckedChange={(highContrast) => setLocalSettings({ ...localSettings, highContrast })}
              />
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="notifications" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><Bell className="h-5 w-5 text-primary" /><span className="text-lg font-bold">Notifications</span></span>
          </AccordionTrigger>
          <AccordionContent>
            <div className="space-y-3">
              <ToggleRow
                label="Son nouvelle commande"
                description="Préférence locale pour signaler une commande entrante."
                checked={localSettings.soundNewOrder}
                onCheckedChange={(soundNewOrder) => setLocalSettings({ ...localSettings, soundNewOrder })}
              />
              <ToggleRow
                label="Son commande en retard"
                description="Préférence locale pour attirer l'attention sur un retard."
                checked={localSettings.soundLateOrder}
                onCheckedChange={(soundLateOrder) => setLocalSettings({ ...localSettings, soundLateOrder })}
              />
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="panino-catalog" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><Sandwich className="h-5 w-5 text-primary" /><span className="text-lg font-bold">Catalogue Pani'NO</span></span>
          </AccordionTrigger>
          <AccordionContent>
            <PaninoProductsManager />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="ingredients" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><Carrot className="h-5 w-5 text-primary" /><span className="text-lg font-bold">Ingrédients</span></span>
          </AccordionTrigger>
          <AccordionContent>
            <IngredientsManager />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="pizzas" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><PizzaIcon className="h-5 w-5 text-primary" /><span className="text-lg font-bold">Pizzas & ingrédients</span></span>
          </AccordionTrigger>
          <AccordionContent>
            <PizzasSection />
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="danger" className="rounded-2xl border bg-card shadow-sm px-4 border-b">
          <AccordionTrigger className="hover:no-underline">
            <span className="flex items-center gap-3"><ShieldAlert className="h-5 w-5 text-destructive" /><span className="text-lg font-bold">Zone sensible</span></span>
          </AccordionTrigger>
          <AccordionContent>
            <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-4">
              <h2 className="font-bold text-destructive">Reset journée sécurisé</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Supprime les commandes en cours, les pizzas, les produits Pani'NO associés et remet les pertes pâtons à zéro.
              </p>
              <div className="mt-3 grid gap-2 sm:grid-cols-[1fr_auto]">
                <Input
                  value={resetCode}
                  onChange={(event) => setResetCode(event.target.value)}
                  placeholder="Tapez RESET pour confirmer"
                  className="h-11"
                />
                <Button variant="destructive" onClick={resetDay} className="h-11" disabled={resetCode.trim().toUpperCase() !== "RESET"}>
                  <RotateCcw className="mr-1 h-4 w-4" /> Reset journée
                </Button>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}

function useLocalControlSettings(): [
  LocalControlSettings,
  (next: LocalControlSettings) => void,
] {
  const [settings, setSettingsState] = useState<LocalControlSettings>(() => {
    if (typeof window === "undefined") return DEFAULT_LOCAL_CONTROL;
    try {
      const stored = window.localStorage.getItem(LOCAL_CONTROL_KEY);
      return stored
        ? { ...DEFAULT_LOCAL_CONTROL, ...JSON.parse(stored) }
        : DEFAULT_LOCAL_CONTROL;
    } catch {
      return DEFAULT_LOCAL_CONTROL;
    }
  });

  const setSettings = (next: LocalControlSettings) => {
    setSettingsState(next);
    try {
      window.localStorage.setItem(LOCAL_CONTROL_KEY, JSON.stringify(next));
    } catch {}
  };

  return [settings, setSettings];
}

function ToggleRow({
  label,
  description,
  checked,
  onCheckedChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border bg-background p-3">
      <div>
        <div className="font-semibold">{label}</div>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}

function PaninoProductsManager() {
  const [products, setProducts] = useState<PaninoProduct[]>([]);
  const [localSettings, setLocalSettings] = useLocalControlSettings();
  const [name, setName] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");

  const reload = async () => {
    const { data, error } = await supabase
      .from("panino_products")
      .select("*")
      .order("sort_order");
    if (error) return toast.error("Impossible de charger les produits Pani'NO");
    setProducts((data as PaninoProduct[]) ?? []);
  };

  useEffect(() => {
    reload();
  }, []);

  const unavailableKeys = new Set(localSettings.disabledPaninoKeys);

  const add = async () => {
    const trimmed = name.trim();
    if (!trimmed) return toast.error("Nom requis");
    const key = slugify(trimmed);
    const maxOrder = products.reduce((max, product) => Math.max(max, product.sort_order), 0);
    const { error } = await supabase.from("panino_products").insert({
      key,
      name: trimmed,
      sort_order: maxOrder + 1,
      active: true,
    });
    if (error) return toast.error("Impossible d'ajouter ce produit");
    toast.success("Produit Pani'NO ajouté");
    setName("");
    reload();
  };

  const startEdit = (product: PaninoProduct) => {
    setEditingId(product.id);
    setEditName(product.name);
  };

  const saveEdit = async () => {
    if (!editingId) return;
    const trimmed = editName.trim();
    if (!trimmed) return toast.error("Nom requis");
    const { error } = await supabase
      .from("panino_products")
      .update({ name: trimmed })
      .eq("id", editingId);
    if (error) return toast.error("Impossible de modifier ce produit");
    toast.success("Produit Pani'NO modifié");
    setEditingId(null);
    setEditName("");
    reload();
  };

  const toggleCheckoutAvailability = (product: PaninoProduct, available: boolean) => {
    const disabledPaninoKeys = available
      ? localSettings.disabledPaninoKeys.filter((key) => key !== product.key)
      : Array.from(new Set([...localSettings.disabledPaninoKeys, product.key]));
    setLocalSettings({ ...localSettings, disabledPaninoKeys });
    toast.success(available ? "Produit marqué disponible" : "Produit marqué indisponible");
  };

  const repairBaseProducts = async () => {
    const { error } = await supabase
      .from("panino_products")
      .update({ active: true })
      .in("key", ["panino", "fishno", "cornet_frites"]);
    if (error) return toast.error("Réparation impossible");
    toast.success("Produits Pani'NO de base réactivés");
    reload();
  };

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Marquez des produits comme indisponibles en caisse sans casser le catalogue technique ni les commandes en cours.
      </p>

      <div className="rounded-xl border border-primary/30 bg-primary/5 p-3 text-sm">
        <div className="font-semibold text-primary">Sécurité catalogue</div>
        <p className="mt-1 text-muted-foreground">
          Les interrupteurs ci-dessous n'écrivent plus dans le champ technique Supabase `active`.
          Ils servent uniquement d'indicateur de disponibilité locale.
        </p>
        <Button variant="outline" onClick={repairBaseProducts} className="mt-3 h-10">
          Réparer les produits de base
        </Button>
      </div>

      <div className="flex gap-2">
        <Input
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Nouveau produit Pani'NO…"
          className="h-11 flex-1"
          onKeyDown={(event) => event.key === "Enter" && add()}
        />
        <Button onClick={add} className="h-11 font-bold">
          <Plus className="mr-1 h-4 w-4" /> Ajouter
        </Button>
      </div>

      <div className="space-y-2">
        {products.map((product) => (
          <div key={product.id} className="flex items-center gap-2 rounded-xl border bg-background p-3">
            <Switch
              checked={!unavailableKeys.has(product.key)}
              disabled={!product.active}
              onCheckedChange={(available) => toggleCheckoutAvailability(product, available)}
            />
            <div className="min-w-0 flex-1">
              {editingId === product.id ? (
                <Input
                  value={editName}
                  onChange={(event) => setEditName(event.target.value)}
                  className="h-9"
                  onKeyDown={(event) => event.key === "Enter" && saveEdit()}
                />
              ) : (
                <>
                  <div className="font-bold">{product.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {!product.active
                      ? "Désactivé techniquement : utilisez Réparer les produits de base si nécessaire"
                      : unavailableKeys.has(product.key)
                        ? "Indisponible en caisse"
                        : "Disponible en caisse"} · clé : {product.key}
                  </div>
                </>
              )}
            </div>
            {editingId === product.id ? (
              <>
                <Button size="sm" variant="outline" onClick={saveEdit} className="h-9">
                  <Check className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => setEditingId(null)} className="h-9">
                  <X className="h-4 w-4" />
                </Button>
              </>
            ) : (
              <Button size="sm" variant="outline" onClick={() => startEdit(product)} className="h-9">
                <Pencil className="h-4 w-4" />
              </Button>
            )}
          </div>
        ))}
        {products.length === 0 && (
          <div className="rounded-xl border border-dashed p-6 text-center text-sm text-muted-foreground">
            Aucun produit Pani'NO
          </div>
        )}
      </div>
    </div>
  );
}

function IngredientsManager() {
  const { ingredients, reload } = useIngredients();
  const [name, setName] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");

  const add = async () => {
    const trimmed = name.trim();
    if (!trimmed) return toast.error("Nom requis");
    const { error } = await supabase.from("ingredients").insert({ name: trimmed });
    if (error) return toast.error("Erreur");
    toast.success("Ingrédient ajouté");
    setName("");
    reload();
  };

  const startEdit = (ing: Ingredient) => {
    setEditingId(ing.id);
    setEditName(ing.name);
  };

  const saveEdit = async () => {
    if (!editingId) return;
    const trimmed = editName.trim();
    if (!trimmed) return toast.error("Nom requis");
    const { error } = await supabase.from("ingredients").update({ name: trimmed }).eq("id", editingId);
    if (error) return toast.error("Erreur");
    toast.success("Ingrédient modifié");
    setEditingId(null);
    setEditName("");
    reload();
  };

  const remove = async (id: string) => {
    if (!confirm("Supprimer cet ingrédient ?")) return;
    const { error } = await supabase.from("ingredients").update({ active: false }).eq("id", id);
    if (error) return toast.error("Erreur");
    toast.success("Ingrédient supprimé");
    if (editingId === id) { setEditingId(null); setEditName(""); }
    reload();
  };

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Gérez la liste des ingrédients disponibles pour les suppléments en caisse.</p>


      <div className="flex gap-2">
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nouvel ingrédient…" className="h-11 flex-1" onKeyDown={(e) => e.key === "Enter" && add()} />
        <Button onClick={add} className="h-11 font-bold"><Plus className="mr-1 h-4 w-4" /> Ajouter</Button>
      </div>

      <div className="flex flex-wrap gap-2">
        {ingredients.map((ing) => (
          <div key={ing.id} className="flex items-center gap-1 rounded-full border bg-background px-3 py-1.5">
            {editingId === ing.id ? (
              <>
                <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="h-7 w-32 text-sm py-0 px-1" onKeyDown={(e) => e.key === "Enter" && saveEdit()} />
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={saveEdit}><Check className="h-3 w-3" /></Button>
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => { setEditingId(null); setEditName(""); }}><X className="h-3 w-3" /></Button>
              </>
            ) : (
              <>
                <span className="text-sm">{ing.name}</span>
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={() => startEdit(ing)}><Pencil className="h-3 w-3" /></Button>
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-destructive" onClick={() => remove(ing.id)}><Trash2 className="h-3 w-3" /></Button>
              </>
            )}
          </div>
        ))}
        {ingredients.length === 0 && <div className="text-sm text-muted-foreground">Aucun ingrédient</div>}
      </div>
    </div>
  );
}

function PizzasSection() {
  const [pizzas, setPizzas] = useState<Pizza[]>([]);
  const [name, setName] = useState("");
  const [ingredients, setIngredients] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);

  const reload = async () => {
    const { data } = await supabase.from("pizzas").select("*").eq("active", true).order("sort_order");
    setPizzas((data as Pizza[]) ?? []);
  };

  useEffect(() => { reload(); }, []);

  const allIngredients = Array.from(new Set(pizzas.flatMap((p) => p.ingredients))).sort();

  const resetForm = () => { setName(""); setIngredients(""); setEditingId(null); };

  const save = async () => {
    const trimmedName = name.trim();
    if (!trimmedName) return toast.error("Nom requis");
    const ing = ingredients.split(",").map((s) => s.trim()).filter(Boolean);
    if (editingId) {
      const { error } = await supabase.from("pizzas").update({ name: trimmedName, ingredients: ing }).eq("id", editingId);
      if (error) return toast.error("Erreur");
      toast.success("Pizza modifiée");
    } else {
      const maxOrder = pizzas.reduce((m, p) => Math.max(m, p.sort_order), 0);
      const { error } = await supabase.from("pizzas").insert({ name: trimmedName, ingredients: ing, sort_order: maxOrder + 1 });
      if (error) return toast.error("Erreur");
      toast.success("Pizza ajoutée");
    }
    resetForm();
    reload();
  };

  const edit = (p: Pizza) => {
    setEditingId(p.id);
    setName(p.name);
    setIngredients(p.ingredients.join(", "));
  };

  const remove = async (p: Pizza) => {
    if (!confirm(`Supprimer "${p.name}" ?`)) return;
    const { error } = await supabase.from("pizzas").update({ active: false }).eq("id", p.id);
    if (error) return toast.error("Erreur");
    toast.success("Pizza supprimée");
    if (editingId === p.id) resetForm();
    reload();
  };

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">Ajoutez ou modifiez les pizzas. Les ingrédients listés ici alimentent automatiquement les extras possibles en caisse.</p>



      <div className="rounded-xl border bg-background p-4 space-y-3">
        <div>
          <Label htmlFor="pizza-name">Nom de la pizza</Label>
          <Input id="pizza-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex : Margherita" className="h-11" />
        </div>
        <div>
          <Label htmlFor="pizza-ing">Ingrédients (séparés par des virgules)</Label>
          <Input id="pizza-ing" value={ingredients} onChange={(e) => setIngredients(e.target.value)} placeholder="Ex : mozzarella, tomate, basilic" className="h-11" />
        </div>
        <div className="flex gap-2">
          <Button onClick={save} className="flex-1 h-11 font-bold">
            <Plus className="mr-1 h-4 w-4" />{editingId ? "Modifier" : "Ajouter"}
          </Button>
          {editingId && (
            <Button variant="outline" onClick={resetForm} className="h-11">Annuler</Button>
          )}
        </div>
      </div>

      <div className="space-y-2">
        {pizzas.map((p) => (
          <div key={p.id} className="flex items-center gap-2 rounded-xl border bg-background p-3">
            <div className="flex-1 min-w-0">
              <div className="font-bold">{p.name}</div>
              <div className="text-xs text-muted-foreground truncate">{p.ingredients.join(" · ") || "Aucun ingrédient"}</div>
            </div>
            <Button size="sm" variant="outline" onClick={() => edit(p)} className="h-9"><Pencil className="h-4 w-4" /></Button>
            <Button size="sm" variant="destructive" onClick={() => remove(p)} className="h-9"><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
        {pizzas.length === 0 && <div className="text-sm text-muted-foreground text-center py-4">Aucune pizza</div>}
      </div>

      <IngredientsManager />

    </div>
  );
}


function Field({ id, label, value, onChange }: { id: string; label: string; value: number | undefined; onChange: (v: number) => void }) {
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} type="number" value={value ?? 0} onChange={(e) => onChange(Number(e.target.value))} className="h-11" />
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: number; tone?: "destructive" | "secondary" }) {
  const color = tone === "destructive" ? "text-destructive" : tone === "secondary" ? "text-secondary" : "text-foreground";
  return (
    <div className="rounded-xl border bg-background p-3 text-center">
      <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
      <div className={`text-2xl font-bold ${color}`}>{value}</div>
    </div>
  );
}

function slugify(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40);
}
